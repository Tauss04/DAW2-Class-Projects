<?php
$cod=1;
include"funciones.php";
$chorizo=dameMisCitas($cod);
var_dump($chorizo);